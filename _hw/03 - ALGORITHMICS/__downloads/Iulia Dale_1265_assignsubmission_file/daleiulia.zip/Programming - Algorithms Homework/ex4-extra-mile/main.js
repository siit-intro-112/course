let arr = prompt('Enter elements separed bu space').split('');
console.log('Number of elements:', arr.length);